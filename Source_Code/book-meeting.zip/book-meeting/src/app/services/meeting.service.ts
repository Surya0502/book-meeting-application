import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MeetingService {
  rooms = Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    name: `Room #${i + 1}`,
  }));

  meetings:any[]=[];

  constructor() {
    // Load meetings from LocalStorage when the service initializes
    this.loadMeetingsFromLocalStorage();
  }

  addMeeting(meeting: any) {
    this.meetings.push({ ...meeting, id: this.meetings.length + 1 });
    this.saveMeetingsToLocalStorage(); // Save to LocalStorage
  }

  getMeetings() {
    return this.meetings;
  }

  deleteMeeting(id: number) {
    this.meetings = this.meetings.filter((meeting) => meeting.id !== id);
    this.saveMeetingsToLocalStorage(); // Save updated meetings to LocalStorage
  }

  checkRoomStatus(date: string, startTime: string, endTime: string) {
    
    return this.rooms.map((room) => {
      const isInUse = this.meetings.some(
        (meeting) =>
          meeting.room === room.name &&
          meeting.date === date &&
          ((startTime >= meeting.startTime && startTime < meeting.endTime) ||
            (endTime > meeting.startTime && endTime <= meeting.endTime))
      );

      const isBooked = this.meetings.some(
        (meeting) =>
          meeting.room === room.name &&
          meeting.date === date &&
          meeting.startTime === startTime &&
          meeting.endTime === endTime
      );

      return {
        ...room,
        status: isBooked ? 'Booked' : isInUse ? 'In-Use' : 'Available',
      };
    });
  }

  // Save meetings to LocalStorage
  private saveMeetingsToLocalStorage() {
    localStorage.setItem('meetings', JSON.stringify(this.meetings));
  }

  // Load meetings from LocalStorage
  private loadMeetingsFromLocalStorage() {
    const storedMeetings = localStorage.getItem('meetings');
    this.meetings = storedMeetings ? JSON.parse(storedMeetings) : [];
  }
}
