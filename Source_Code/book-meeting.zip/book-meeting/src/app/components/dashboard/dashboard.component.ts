import { Component } from '@angular/core';
import { MeetingService } from '../../services/meeting.service';
import { BookMeetingModalComponent } from '../book-meeting-modal/book-meeting-modal.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports:[BookMeetingModalComponent,CommonModule,FormsModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent {
  meetings:any[] = [];
  roomMeetings :any[]= [];
  rooms :any[]= [];
  selectedRoom = '';
  showModal = false;

  constructor(private ms: MeetingService) {
    this.meetings = this.ms.getMeetings();
    this.rooms = this.ms.rooms;
    this.selectedRoom = this.rooms[0]?.name; // Default to the first room
    this.filterMeetingsByRoom();
  }

  delete(id: number) {
    if (confirm('Are you sure you want to delete this meeting?')) {
      this.ms.deleteMeeting(id);
      this.meetings = this.ms.getMeetings();
      this.filterMeetingsByRoom();
    }
  }

  openModal() {
    this.showModal = true; // Show booking modal
  }

  closeModal() {
    this.showModal = false; // Hide booking modal
    this.meetings = this.ms.getMeetings(); // Refresh meetings
    this.filterMeetingsByRoom(); // Refresh filtered meetings
  }

  filterMeetingsByRoom() {
    this.roomMeetings = this.meetings.filter(
      (meeting) => meeting.room === this.selectedRoom
    );
  }
}
