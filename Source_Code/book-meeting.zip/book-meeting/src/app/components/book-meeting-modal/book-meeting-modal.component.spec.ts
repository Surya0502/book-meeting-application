import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookMeetingModalComponent } from './book-meeting-modal.component';

describe('BookMeetingModalComponent', () => {
  let component: BookMeetingModalComponent;
  let fixture: ComponentFixture<BookMeetingModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BookMeetingModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BookMeetingModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
