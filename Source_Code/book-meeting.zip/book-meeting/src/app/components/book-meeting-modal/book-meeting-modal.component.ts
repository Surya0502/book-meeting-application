import { Component, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MeetingService } from '../../services/meeting.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-book-meeting-modal',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './book-meeting-modal.component.html',
  styleUrls: ['./book-meeting-modal.component.css']
})
export class BookMeetingModalComponent {
  data = {
    userName: '',
    date: '',
    startTime: '',
    endTime: '',
    room: '',
    agenda: '',
  };
  errorMessage = '';
  roomStatuses :any[]= [];

  @Output() close = new EventEmitter<void>();

  constructor(public ms: MeetingService) {}

  public checkRoomStatus() {
    if (this.data.date && this.data.startTime && this.data.endTime) {
      this.roomStatuses = this.ms.checkRoomStatus(
        this.data.date,
        this.data.startTime,
        this.data.endTime
      );
      console.log(this.roomStatuses)
    } else {
      this.roomStatuses = [];
    }
  }

  book() {
    const startTimeMinutes = this.timeToMinutes(this.data.startTime);
    const endTimeMinutes = this.timeToMinutes(this.data.endTime);
    // Validation logic
    if (!this.data.userName || !this.data.agenda || !this.data.date || !this.data.startTime || !this.data.endTime || !this.data.room) {
      this.errorMessage = 'All fields are required.';
      return;
    }

    if (endTimeMinutes <= startTimeMinutes) {
      this.errorMessage = 'End time must be later than start time.';
      return;
    }

    const duration = endTimeMinutes - startTimeMinutes;
    if (duration < 30) {
      this.errorMessage = 'Meeting should be at least 30 minutes.';
      return;
    }

    const meetingDate = new Date(this.data.date);
    const dayOfWeek = meetingDate.getDay(); 
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      this.errorMessage = 'Meeting rooms can only be booked Monday to Friday.' ;
      return;
    }

    const startHour = parseInt(this.data.startTime.split(':')[0], 10);
    const endHour = parseInt(this.data.endTime.split(':')[0], 10);

    if (startHour < 9 || endHour > 18) {
      this.errorMessage = 'Meeting rooms can only be booked between 9:00 AM and 6:00 PM.' ;
      return;
    }

    this.ms.addMeeting(this.data);
    this.errorMessage = '';
    this.close.emit(); 
  }

  private timeToMinutes(timeStr:string) {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
  }

  public closeModal() {
    this.close.emit(); 
  }
}


